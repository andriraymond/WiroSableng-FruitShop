<!DOCTYPE html>
<html lang="en">

<head>
    <title>Wiro Sableng</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/typed.min.js"></script>

    <script>
        window.onload = function () {
            var typed = new Typed('.typing-effect', {
                strings: [
                    "Let me tell you, ^700 a hero tells no lie.",
                    "I am a hero ^400 for tomorrow.",
                    "Many do not know that ^400.^400.^400.",
                    "I code HTML, ^400 CSS, ^400 and JS just like you.",
                    "... :p"
                ],
                typeSpeed: 50,
                backDelay: 1500,
                loop: 1
            });
        }
    </script>
</head>

<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">FruitShop</a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="shop.php">Shop</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="status.php">Status</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="testimonial.php">Testimonials</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="voting.php">Fruit Voting</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="almanac.php">Fruit Almanac</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="login.php">Login</a>
            </li>
        </ul>
    </nav>

    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <div class="row">
                <div class="col-md-3 offset-md-1"><img class="rounded-circle w-50 mx-auto d-block"
                        src="images/wiro.jpg"> </div>
                <div class="col-md-8">
                    <h1>Wiro Sableng</h1>
                    <h2><span class="typing-effect"></span></h2>
                    <p>Well, I am a hero of finggers and working as a software developer.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h3>Lastest status</h3>
                <p class="font-weight-bold">Wirll!</p>
                <p><span class="small font-italic">2018-10-08 11:41:51</span></p>
            </div>
            <div class="col-md-5">
                <div class="row">
                    <div class="col-md-4">
                        <img class="img-fluid rounded-circle" src="images/grape.jpg">
                    </div>
                    <div class="col-md-8">
                        <h3>Most voted fruit</h3>
                        <p><span>Grape</span> is the most voted fruit. The latin name of this fruit is <i><span>Vitis
                                    vinifera</span></i>.
                            We can find this kind of fruit in <span>Green, Purple, Red, &amp; White</span>. It gets
                            <span>18</span> votes.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-4">
                        <img class="img-fluid rounded-circle" src="images/strawberry.jpg">
                    </div>
                    <div class="col-md-8">
                        <h3>Strawberry <span class="badge badge-primary">New</span></h3>
                        <p>Welcome to the competition! The latin name of this fruit is <i><span>Fragaria</span></i>.
                            We can find this kind of fruit in <span>Red &amp; Green</span>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>