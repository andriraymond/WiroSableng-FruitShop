<!DOCTYPE html>
<html lang="en">

<head>
    <title>Wiro Sableng</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">FruitShop</a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="shop.php">Shop</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="status.php">Status</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="testimonial.php">Testimonials</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="voting.php">Fruit Voting</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="almanac.php">Fruit Almanac</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="login.php">Login</a>
            </li>
        </ul>
    </nav>

    <div class="container" style="margin-top:20px">
        <div class="row">
            <div class="col-md-3"><img class="rounded-circle w-50 mx-auto d-block" src="images/wiro.jpg"> </div>
            <div class="col-md-9">
                <h1>Registration</h1>
                <h3>To register, please complete the following form.</h3>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top:20px">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <form action="action_register.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="full_name"><b>Full name*</b></label>
                                <input type="text" id="full_name" name="full_name" class="form-control" value="">
                            </div>
                            <div class="form-group">
                                <label for="email" style="margin-top: 10px;"><b>Email*</b></label>
                                <input type="text" id="email" name="email" class="form-control" value="">
                            </div>
                        </div>
                        <div class="col-md-4 border-left">
                            <div class="form-group">
                                <label for="password"><b>Password*</b></label>
                                <input type="password" id="password" name="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="repassword" style="margin-top: 10px;"><b>Retype password*</b></label>
                                <input type="password" id="repassword" name="repassword" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4 border-left">
                            <div class="form-group">
                                <label for="description"><b>Describe about yourself</b></label>
                                <textarea rows="3" id="description" name="description" class="form-control"></textarea>
                            </div>
                            <span><i><b>Note:</b> fields with * are required</i></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 offset-md-8">
                            <input class="btn btn-primary btn-block" type="submit" value="Register">
                        </div>
                    </div>
                    <input type="hidden" name="action" value="register">
                </form>
            </div>
        </div>
    </div>
</body>

</html>